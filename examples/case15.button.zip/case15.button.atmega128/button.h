#ifndef BUTTON_H
#define BUTTON_H

void initButton();
bool isButtonPressed();

#endif // BUTTON_H
