#define F_CPU 4000000UL  // 4 MHz
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdbool.h>
#include "led.h"
#include "button.h"

int main() {

    initLeds();
	initButton();

	bool wasPressed = false;

    while (1) {
	    if (!wasPressed && isButtonPressed() ) {
            ledOn(1);
			_delay_ms(10);
			wasPressed = true;
        } else if (wasPressed && !isButtonPressed()) {
		    ledOff(1);
			_delay_ms(10);
			wasPressed = false;
		}
    }
    
    return 0;
}

