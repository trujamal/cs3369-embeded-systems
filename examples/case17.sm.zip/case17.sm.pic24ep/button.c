#include "Compiler.h"
#include "event.h"
#include "macros.h"

// button is connected to pin D15
// when button is pressed, D15 reads high.
// when button is not pressed, D15 reads low.

void initButton() {
    TRISDbits.TRISD15 = 1;  // set input
}

void pollButton() {
    if (PORTDbits.RD15 == 1) evButton = Button_Pressed;
    else evButton = Button_Released;
}
