#ifndef EVENT_H
#define	EVENT_H

typedef enum {
    Button_Pressed,
    Button_Released,
    Delay_Expired,
    NONE,
} Event;

extern volatile Event evButton, evTimer;

#endif	/* EVENT_H */

