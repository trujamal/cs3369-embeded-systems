#include <stdbool.h>
#include "Compiler.h"
#include "ConfigurationBits.h"
#include "led.h"

#include "delay.h"
#include "button.h"

#include "event.h"
#include "state.h"
#include "macros.h"

Event volatile evButton, evTimer;

int main() {
    initLeds();
    initButton();
    evButton = NONE;
    evTimer = NONE;
    
    State st = S0_Released;
    
    while (1) {

        pollButton();

        switch (st) {
            case S0_Released:
                //ledOff(1);
                if (evButton == Button_Pressed) {
                    ledOn(1);
                    startDelay();
                    st = S1_Pressed;
                }
                break;
            case S1_Pressed:
                //ledOn(1);
                if (evTimer == Delay_Expired) {
                    st = S2_Pressed;
                }
                break;
            case S2_Pressed:
                // ledOn(1);
                if (evButton == Button_Released) {
                    ledOff(1);
                    startDelay();
                    st = S3_Released;
                }
                break;
            case S3_Released:
                // ledOff(1);
                if (evTimer == Delay_Expired) {
                    st = S0_Released;
                }
                break;
            default:
                // only for errors to reset to initial state
                st = S0_Released;
                evButton = NONE;
                evTimer = NONE;
        }
    }

    return 0;
}
