#ifndef BUTTON_H
#define BUTTON_H

void initButton();

void pollButton();

#endif // BUTTON_H
