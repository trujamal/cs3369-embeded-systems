/* 
 * File:   macros.h
 * Author: qijun
 *
 * Created on October 2, 2015, 11:30 AM
 */

#ifndef MACROS_H
#define	MACROS_H

//#define Delay

#endif	/* MACROS_H */

