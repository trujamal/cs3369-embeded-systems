#ifndef BUTTON_H
#define BUTTON_H

void initButton();

extern bool volatile buttonPressed;

#endif // BUTTON_H
