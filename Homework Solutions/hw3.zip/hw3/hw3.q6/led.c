#include <stdint.h>
#include "Compiler.h"

// Copy your code for question 2 here.

void initLeds()

void ledOn(uint8_t sel)

void ledOff(uint8_t sel)
