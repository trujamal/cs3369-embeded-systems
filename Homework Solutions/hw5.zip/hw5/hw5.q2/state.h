#ifndef STATE_H
#define	STATE_H

typedef enum {
    S0_Released = 0,
    S1_Pressed = 1,
    S2_Pressed = 2,
    S3_Released = 3,
} State;

#endif	/* STATE_H */

