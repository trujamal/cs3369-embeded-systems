#ifndef PWM_H
#define	PWM_H

void initPWM();

void pwmOn();

void pwmOff();

#endif	/* PWM_H */

