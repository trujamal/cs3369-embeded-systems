#include "event.h"

// same event only exists once in que

// initialize all elements in Queue to END
void initQueue(Queue* que) {
}

// test if Queue has pending events
bool isEmpty(Queue* que) {
}

// return the current pending event and replace the current with the next event
uint8_t pop(Queue* que) {
}

// add a new event to Queue.
// if ev is not in que, alway append ev to the end of que
// if ev is in que already, do not append ev
void append(Queue* que, uint8_t ev) {
}
